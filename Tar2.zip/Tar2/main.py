# קבוצה: 150060.31.5783.01, 150060.31.5783.43
# רחל לאה כהן: 211372156
# הודיה שנקר: 211720503

# This code is always interpreted, like normal Python.
# It is not compiled to C.

import hello
import vmTranslator

hello.say_hello()
vmTranslator.recursive_div("C:\\Users\\rache\\PycharmProjects\\Cython\\Tar2\\08")